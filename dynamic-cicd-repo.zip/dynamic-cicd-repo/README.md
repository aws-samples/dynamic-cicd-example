# Sample application

This is a sample application for deployment - Below is the application structure:

```bash
.
├── appfrontend                 <-- Project directory for the front-end App.
├── buildspec.yml               <-- File containing the build commands and related settings that CodeBuild uses to run a build.
├── appbackend                  <-- Project directory for the back-end Go App.
├── README.md                   <-- Readme file
└── template.yaml               <-- File to create the AWS CloudFormation package in the build stage of CodeBuild.
```

